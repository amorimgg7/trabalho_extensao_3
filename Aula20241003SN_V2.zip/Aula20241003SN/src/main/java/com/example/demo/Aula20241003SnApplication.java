package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula20241003SnApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula20241003SnApplication.class, args);
	}

}

package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula20241003SnApplicationTests {

	@Test
	void contextLoads() {
	}

}

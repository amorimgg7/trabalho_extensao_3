package com.example.demo;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {

	private PessoaNet pnet = new LojaCliente().getPessoaNet();
	
	@GetMapping("/")
	public String index(Model model) {
		try {
			model.addAttribute("pessoas", pnet.obterTodos().execute().body());
		} catch (IOException e) {
			System.out.println("Erro");
		}
		return "index";
	}
	
}
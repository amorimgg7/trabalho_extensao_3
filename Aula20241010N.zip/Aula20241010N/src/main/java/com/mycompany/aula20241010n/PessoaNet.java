/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.aula20241010n;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface PessoaNet {

    @GET("pessoa")
    Call<List<Pessoa>> obterTodos();

    @GET("pessoa/{id}")
    Call<Pessoa> obter(@Path("id") Integer id);

    @POST("pessoa")
    Call<Void> incluir(@Body Pessoa p);

    @PUT("pessoa/{id}")
    Call<Void> alterar(@Path("id") Integer id, @Body Pessoa p);

    @DELETE("pessoa/{id}")
    Call<Void> excluir(@Path("id") Integer id);

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula20241010n;

/**
 *
 * @author denis.cople
 */
public class Pessoa {
    public Integer codigo;
    public String nome;
    public Integer idade;

    public Pessoa() {
    }

    public Pessoa(Integer codigo, String nome, Integer idade) {
        this.codigo = codigo;
        this.nome = nome;
        this.idade = idade;
    }

}

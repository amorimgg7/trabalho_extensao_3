/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula20241010n;

public class Aula20241010N {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello World!");
        PessoaNet pnet = new LojaCliente().getPessoaNet();
        pnet.obterTodos().execute().body().forEach(
           p -> System.out.println(p.nome+" :: "+p.idade)
        );
    }
}

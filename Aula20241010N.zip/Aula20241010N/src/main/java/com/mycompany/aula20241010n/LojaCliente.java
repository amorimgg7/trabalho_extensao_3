/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula20241010n;

import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

public class LojaCliente {
    
    private Retrofit retrofit = new Retrofit.Builder()
                                .baseUrl("http://localhost:8080/")
                                .addConverterFactory(JacksonConverterFactory.create())
                                .build();

    public PessoaNet getPessoaNet(){
        return retrofit.create(PessoaNet.class);
    }
}

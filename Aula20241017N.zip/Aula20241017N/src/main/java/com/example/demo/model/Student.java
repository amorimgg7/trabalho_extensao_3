package com.example.demo.model;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long id;
	public String name;

	@ManyToMany
	@JoinTable(name = "course_like", 
	   joinColumns = @JoinColumn(name = "student_id"), 
	   inverseJoinColumns = @JoinColumn(name = "course_id"))
	public Set<Course> likedCourses;
}

package com.example.demo.model.dao;

import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Perfil;

public interface PerfilDAO extends JpaRepository<Perfil,UUID>{

}

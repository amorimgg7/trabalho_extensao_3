package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.controller.dto.CourseLikeDTO;
import com.example.demo.model.Course;
import com.example.demo.model.Student;
import com.example.demo.model.dao.CourseDAO;
import com.example.demo.model.dao.StudentDAO;

@RestController
@RequestMapping("/courselike")
@CrossOrigin(origins = "*")
public class CourseLikeController {
	
	@Autowired
	StudentDAO daoStudent;
	@Autowired
	CourseDAO daoCourse;
	
	@GetMapping("student")
	public List<Student> getStudents(){
		return daoStudent.findAll();		
	}

	@GetMapping("course")
	public List<Course> getCourses(){
		return daoCourse.findAll();		
	}
	
	@PostMapping("student")
	public void addStudent(@RequestBody Student student) {
		daoStudent.save(student);
	}

	@PostMapping("course")
	public void addCourse(@RequestBody Course course) {
		daoCourse.save(course);
	}
	
	@PatchMapping("like/{idStudent}/{idCourse}")
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void like(@PathVariable Long idStudent, @PathVariable Long idCourse) {
		System.out.println(idStudent + " :: "+idCourse);
		Student student = daoStudent.findById(idStudent).get();
		Course course = daoCourse.findById(idCourse).get();
		student.likedCourses.add(course);
		daoStudent.save(student);
	}
	

	@GetMapping("liked")
	public List<CourseLikeDTO> getLiked(){
		List<CourseLikeDTO> lista = new ArrayList<>();
		daoStudent.findAll().stream()
		          .sorted((o1,o2) ->o1.name.compareTo(o2.name))
		          .forEach(
				s -> s.likedCourses.forEach(
						c -> lista.add(new CourseLikeDTO(s.name,c.name))
				)
		);
		return lista;		
	}
	
}

package com.example.demo.controller.dto;

public class CourseLikeDTO {
	public String studentName;
	public String courseName;
	public CourseLikeDTO(String studentName, String courseName) {
		this.studentName = studentName;
		this.courseName = courseName;
	}
	public CourseLikeDTO() {
	}
}

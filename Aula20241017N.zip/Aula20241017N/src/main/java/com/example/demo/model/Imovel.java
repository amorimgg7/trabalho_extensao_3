package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Imovel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long id;
	public String tipo;
	public String logradouro;
	public String cidade;
	public String uf;
	
	
	@ManyToOne
	@JoinColumn(name = "proprietario_id")
	@JsonIgnore
	public Proprietario proprietario;

}

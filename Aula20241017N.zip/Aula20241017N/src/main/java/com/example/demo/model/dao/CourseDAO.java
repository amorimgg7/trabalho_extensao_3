package com.example.demo.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Course;

public interface CourseDAO extends JpaRepository<Course, Long>{

}

package com.example.demo.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Imovel;

public interface ImovelDAO extends JpaRepository<Imovel, Long>{

}

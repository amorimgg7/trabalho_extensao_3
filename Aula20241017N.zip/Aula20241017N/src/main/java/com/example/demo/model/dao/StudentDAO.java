package com.example.demo.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Student;

public interface StudentDAO extends JpaRepository<Student, Long>{

}

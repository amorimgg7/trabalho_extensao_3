package com.example.demo.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Perfil;
import com.example.demo.model.Usuario;
import com.example.demo.model.dao.PerfilDAO;
import com.example.demo.model.dao.UsuarioDAO;

@RestController
@RequestMapping("/usuario")
@CrossOrigin(origins = "*")
public class UsuarioController {
	
	@Autowired
	UsuarioDAO daoUsuario;
	@Autowired
	PerfilDAO daoPerfil;
	
	@GetMapping
	public List<Usuario> obterUsuarios(){
		return daoUsuario.findAll();
	}
	
	@PostMapping
	public void criarUsuario(@RequestBody Usuario usuario) {
		daoUsuario.save(usuario);
	}
	
	@PostMapping("{id}/perfil")
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void criarPerfil(@PathVariable UUID id, @RequestBody Perfil perfil) {
		daoPerfil.save(perfil);
		Usuario usu = daoUsuario.findById(id).get();
		usu.perfil = perfil;
		daoUsuario.save(usu);
	}

}

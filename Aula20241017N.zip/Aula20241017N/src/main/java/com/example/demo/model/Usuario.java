package com.example.demo.model;

import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public UUID id;
	public String email;
	public String senha;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "perfil_id")
	public Perfil perfil;

}

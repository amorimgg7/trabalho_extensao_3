package com.example.demo.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Proprietario;

public interface ProprietarioDAO extends JpaRepository<Proprietario, Long> {

}

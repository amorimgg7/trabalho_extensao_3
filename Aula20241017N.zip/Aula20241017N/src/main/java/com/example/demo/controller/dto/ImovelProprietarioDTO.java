package com.example.demo.controller.dto;

public class ImovelProprietarioDTO {
	public String tipo;
	public String logradouro;
	public String cidade;
	public String uf;
	public String nome;
	public String telefone;
	
	public ImovelProprietarioDTO(String tipo, String logradouro, String cidade, String uf, String nome,
			String telefone) {
		this.tipo = tipo;
		this.logradouro = logradouro;
		this.cidade = cidade;
		this.uf = uf;
		this.nome = nome;
		this.telefone = telefone;
	}
	
	public ImovelProprietarioDTO() {
		
	}
	
}

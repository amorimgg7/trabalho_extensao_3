package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.controller.dto.ImovelProprietarioDTO;
import com.example.demo.model.Imovel;
import com.example.demo.model.Proprietario;
import com.example.demo.model.dao.ImovelDAO;
import com.example.demo.model.dao.ProprietarioDAO;

@RestController
@RequestMapping("/imob")
@CrossOrigin(origins = "*")
public class ImobiliariaController {
	
	@Autowired
	ProprietarioDAO daoProp;
	@Autowired
	ImovelDAO daoImovel;
	
	@PostMapping("prop")
	public void criarProprietario(@RequestBody Proprietario prop) {
		daoProp.save(prop);
	}
	
	@GetMapping("prop")
	public List<Proprietario> obterProps() {
		return daoProp.findAll();
	}
	
	@GetMapping("prop/{id}")
	public Proprietario obterProprietario(@PathVariable Long id) {
		return daoProp.findById(id).get();
	}

	@PostMapping("prop/{id}/imovel")
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void criarImovel(@PathVariable Long id, @RequestBody Imovel imovel) {
		Proprietario prop = daoProp.findById(id).get();
		imovel.proprietario = prop;
		daoImovel.save(imovel);
	}
	
	@GetMapping("imoveis")
	public List<ImovelProprietarioDTO> obterImoveis() {
		List<ImovelProprietarioDTO> lista = new ArrayList<>();
		daoImovel.findAll().forEach(
				t -> lista.add(new ImovelProprietarioDTO(t.tipo,t.logradouro,t.cidade,t.uf,
						t.proprietario.nome,t.proprietario.telefone)));
		return lista;
	}
	
}
